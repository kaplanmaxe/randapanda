(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['percolate:paginated-subscription'] = {};

})();

//# sourceMappingURL=percolate_paginated-subscription.js.map
